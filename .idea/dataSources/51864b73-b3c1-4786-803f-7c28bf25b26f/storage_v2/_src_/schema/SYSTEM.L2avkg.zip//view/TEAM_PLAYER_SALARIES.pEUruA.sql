create view TEAM_PLAYER_SALARIES as
SELECT Teams.name AS TeamName, SUM(Players.salary) AS TotalSalaryPaid
FROM (Teams JOIN Players ON Teams.id = Players.team_id) GROUP BY Teams.name
/

